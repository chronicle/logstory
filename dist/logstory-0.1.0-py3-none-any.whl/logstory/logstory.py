"""CLI for Logstory."""

import datetime
import glob
import os
import sys
import uuid

from absl import app
from absl import flags
from google.oauth2 import service_account

UTC = datetime.timezone.utc


# Validation function to check if the string is a valid UUID4
def is_valid_uuid4(value):
  """Abseil flag validation for customer id."""
  try:
    val = uuid.UUID(value, version=4)
    # Check if the string conforms to the UUID4 format
    return str(val) == value
  except ValueError:
    return False


def validate_service_account_json(json_path):
  """Abseil flag validation for credentials file."""
  # Check if the file exists
  if not os.path.isfile(json_path):
    raise FileNotFoundError(
        f"File does not exist: {json_path}.\n"
        "Please provide the complete path to a JSON credentials file.\n"
    )
  try:
    # Attempt to load the service account credentials
    _ = service_account.Credentials.from_service_account_file(json_path)
    # If it loads successfully, the path is valid
    return True, "The JSON file is valid."
  except Exception as e:
    # If an error occurs, return False and the error message
    # pylint: disable-next=broad-exception-raised
    raise Exception(f"The JSON file is invalid: {e}") from e


FLAGS = flags.FLAGS
flags.DEFINE_string(
    "credentials_path",
    None,
    "Path to JSON credentials for Ingestion API Service account.",
    short_name="c",
    required=False,  # conditionally req. depending on subcommand
)
flags.DEFINE_string(
    "customer_id",
    None,
    "Customer ID for SecOps instance, found on `/settings/profile/`.",
    required=False,  # conditionally req. depending on subcommand
)
flags.DEFINE_string(
    "region",
    None,  # "US" (default) is a regionless base url, so None works here.
    "SecOps tenant's region (Default=US). Used to set ingestion API base URL.",
    short_name="r",
    required=False,
)
flags.DEFINE_bool("entities", False, "Load Entities instead of Events")
flags.DEFINE_bool("three_day", False, "Load Entities instead of Events")
flags.DEFINE_string(
    "timestamp_delta",
    None,
    "Determines how datetimes in logfiles are updated. "
    "It is expressed in any/all: days, hours, minutes (d, h, m) (Default=1d) "
    "Examples: [1d, 1d1h, 1h1m, 1d1m, 1d1h1m, 1m1h, ...] "
    "Setting only `Nd` preserves the original HH:MM:SS but updates date. "
    "Nh/Nm subtracts an additional offset from that datetime, to facilitate "
    "running logstory more than 1x per day. ",
    required=False,
)


def _get_current_time():
  """Returns the current time in UTC."""
  return datetime.datetime.now(UTC)


def list_usecases_logtypes():
  list_usecases(print_logtypes=True)


def get_usecases():
  """NOTE: this is *all* usecases, not just enabled in `events-24h`"""
  usecase_dirs = glob.glob(
      os.path.join(os.path.dirname(os.path.abspath(__file__)), "usecases/*")
  )
  usecases = []
  for usecase_dir in usecase_dirs:
    parts = os.path.split(usecase_dir)
    usecases.append(parts[-1])
  return usecases


# Define subcommands
def list_usecases(print_logtypes=False, entities=False):
  """Walk the usecases/ dir and print the dir names."""
  entity_or_event = "ENTITIES" if entities else "EVENTS"
  usecase_dirs = glob.glob(
      os.path.join(os.path.dirname(os.path.abspath(__file__)), "usecases/*")
  )
  usecases = []
  logypes_map = {}
  for usecase_dir in usecase_dirs:
    parts = os.path.split(usecase_dir)
    usecases.append(parts[-1])
    log_types = []
    if print_logtypes:
      for adir in glob.glob(os.path.join("./", usecase_dir, entity_or_event, "*.log")):
        log_types.append(os.path.splitext(os.path.split(adir)[-1])[0])
      logypes_map[usecases[-1]] = log_types
  for usecase in sorted(usecases):
    print(usecase)
    if print_logtypes:
      for log_type in sorted(logypes_map[usecase]):
        print(f"\t{log_type}")


def get_logtypes(usecase, entities=False):
  """Walk the subdirs in usecases and print the file base names."""
  print(f"Executing usecase: {usecase}")
  # Access common flags with FLAGS.flag_name

  entity_or_event = "ENTITIES" if entities else "EVENTS"
  usecase_dir = f"{os.path.split(__file__)[0]}/usecases/{usecase}/{entity_or_event}/"
  log_files = glob.glob(usecase_dir + "*.log")
  log_types = []
  for log_file in log_files:
    print(f"log_file: {log_file}")
    parts = os.path.split(log_file)
    log_type = os.path.splitext(parts[-1])[0]
    log_types.append(log_type)
    print(f"log_type: {log_type}")
  return log_types


def local_main(argv):
  """Parse args and call the appropriate function."""
  if len(argv) < 2:
    custom_help()
    return 1
  # parse the flags
  FLAGS(argv)
  # Some params are conditionally required
  # Check if either "replay_usecase" or "replay_usecase_logtype" is in argv
  requires_customer_and_credentials = any(
      arg in argv for arg in ["replay_usecase", "replay_usecase_logtype"]
  )
  # Check if customer_id or credentials_path is missing
  missing_customer_or_credentials = not FLAGS.customer_id or not FLAGS.credentials_path
  # Combine the conditions
  if requires_customer_and_credentials and missing_customer_or_credentials:
    # Handle the case where either customer_id or credential_path is missing
    raise ValueError(
        "The following flags must be set when using the replay_usecase and"
        " list_usecases_logtypes subcommands:\n\t--credentials_path,"
        " --customer_id, ..."
    )

  # optionality was determined above. now validate if the params are present.
  if FLAGS.credentials_path:
    flags.register_validator(
        "credentials_path",
        validate_service_account_json,
        message=("--credentials_path must be JSON credentials for a Service Account"),
    )
  if FLAGS.customer_id:
    flags.register_validator(
        "customer_id",
        is_valid_uuid4,
        message="--customer_id must be a UUID4",
    )
  # must parse flags again to enforce validators
  FLAGS(argv)

  # if present and valid, set as env vars
  if FLAGS.customer_id:
    os.environ["CUSTOMER_ID"] = FLAGS.customer_id
    print(f"The customer_id is: {os.environ['CUSTOMER_ID']}")

  if FLAGS.credentials_path:
    os.environ["CREDENTIALS_PATH"] = FLAGS.credentials_path
    print(f"The credentials_path is: {os.environ['CREDENTIALS_PATH']}")

  # should us -> '' logic be here or in the main.py file?
  if FLAGS.region:
    os.environ["REGION"] = FLAGS.region

  if len(argv) < 2:
    print("Usage: %s {list_usecases, command_two} [options]" % argv[0])
    return 1
  command = argv[1]
  if command == "list_usecases":
    return list_usecases()
  if command == "list_usecases_logtypes":
    return list_usecases_logtypes()

  # late import here due to globals in the module
  from . import main as imported_main

  if command == "replay_usecases":
    usecases = get_usecases()
    logtypes = "*"
  elif command == "replay_usecase":
    usecase = argv[2]  # flaky?
    usecases = [
        usecase,
    ]
    logtypes = get_logtypes(usecase, entities=FLAGS.entities)
  elif command == "replay_usecase_logtype":
    usecase = argv[2]  # flaky?
    usecases = [
        usecase,
    ]
    logtypes = argv[3].split(",")
  else:
    print("Unknown command: %s" % command)
    return 1

  logstory_exe_time = datetime.datetime.now(datetime.timezone.utc)
  for use_case in usecases:
    logstory_exe_time = _get_current_time()
    if command == "replay_usecases":
      logtypes = get_logtypes(use_case)

    old_base_time = None  # resets for each usecase
    for log_type in logtypes:
      log_type = log_type.strip()
      print(f"usecase: {use_case}")
      print(f"{logtypes}, |{log_type}|")
      old_base_time = imported_main.replay_usecase_logtype(
          use_case,
          log_type,
          logstory_exe_time,
          old_base_time,
          timestamp_delta=FLAGS.timestamp_delta or None,
          entities=FLAGS.entities,
      )
    print(
        f"""UDM Search for the loaded logs:
    metadata.ingested_timestamp.seconds >= {int(logstory_exe_time.timestamp())}
    metadata.ingestion_labels.key = "log_replay"
    metadata.ingestion_labels.value = "true"
    metadata.ingestion_labels.key = "replayed_from"
    metadata.ingestion_labels.value = "logstory"
    metadata.ingestion_labels.key = "source_usecase"
    metadata.ingestion_labels.value = "{use_case}"
    """
    )

  return "Success Events!"


def custom_help():
  help_text = """
    Usage: logstory.py <command> [command options]

    Commands:
      list_usecases            List the usecases

      list_usecases_logtypes   List each logtype for each usecase

      replay_usecases          Replay all usecases

      replay_usecase           Replay a specific usecase
         examples:
           replay_usecase AWS
           replay_usecase GITHUB
           ...

      replay_usecase_logtype   Replay a specific usecase with a specific log type
         examples:
           replay_usecase_logtype AWS AWS_CLOUDTRAIL
           replay_usecase_logtype WORKSPACE GCP_CLOUDAUDIT
           replay_usecase_logtype AWS AWS_CLOUDTRAIL,AWS_WAF # No spaces without quotes
           replay_usecase_logtype AWS "AWS_CLOUDTRAIL, AWS_WAF" # Use quotes if there are spaces
           ...

    Usage Examples:
      python ./logstory.py list_usecases

      python ./logstory.py list_usecases_logtypes

      python ./logstory.py replay_usecases --flagfile=config.cfg

      python ./logstory.py replay_usecase AWS --flagfile=config.cfg
      python ./logstory.py replay_usecase AWS --flagfile=config.cfg --timestamp_delta=1d
      python ./logstory.py replay_usecase AWS --flagfile=config.cfg --timestamp_delta=1d1h
      python ./logstory.py replay_usecase AWS --flagfile=config.cfg --timestamp_delta=1d1h1m
      python ./logstory.py replay_usecase AWS --flagfile=config.cfg --timestamp_delta=1h30m

      python ./logstory.py replay_usecase_logtype AWS AWS_CLOUDTRAIL,AWS_WAF --flagfile=config.cfg
      python ./logstory.py replay_usecase_logtype AWS "AWS_CLOUDTRAIL, AWS_WAF" --flagfile=config.cfg

      # test the too big payload
      python ./logstory.py replay_usecase_logtype RECON_CISA POWERSHELL --flagfile=config.cfg

      # test udm api method
      python ./logstory.py replay_usecase_logtype HIGH_RISK_USER_DOWNLOAD_EXECUTABLE_FROM_MACRO UDM --flagfile=config.cfg

      # change loglevel
      PYTHONLOGLEVEL=debug python ./logstory.py ...

      #
      # Entities
      #

      PYTHONLOGLEVEL=debug python ./logstory.py replay_usecase_logtype WORKSPACE WORKSPACE_USERS --flagfile=config.cfg --entities

      PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase AWS --flagfile=config.cfg --timestamp_delta=1d


      # Entities 3day
      PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase_logtype MISP MISP_IOC --flagfile=config.cfg --entities --three_day
      # Entities 24hr
      PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase_logtype WHOIS OKTA_USER_CONTEXT --flagfile=config.cfg --entities

      # api == entities
      PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase_logtype HIGH_RISK_USER_DOWNLOAD_EXECUTABLE_FROM_MACRO GCP_IAM_ANALYSIS --flagfile=config.cfg --entities

      # Events 3day
      PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase_logtype MISP POWERSHELL --flagfile=config.cfg --three_day


       PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase_logtype MISP WINDOWS_SYSMON --flagfile= config_secops_lab.cfg --three_day

      # Events 24hr
      PYTHONLOGLEVEL=debug  python ./logstory.py replay_usecase_logtype AWS AWS_CLOUDTRAIL --flagfile=config.cfg

      # pip install ....
      PYTHONLOGLEVEL=debug logstory replay_usecase_logtype AWS AWS_CLOUDTRAIL --flagfile=config.cfg

    """
  print(help_text)
  print(FLAGS)


def entry_point():
  if "--help" in sys.argv:
    custom_help()
    sys.exit(1)
  app.run(local_main)  # evaluates the flags


if __name__ == "__main__":
  if "--help" in sys.argv:
    custom_help()
    sys.exit(1)
  app.run(local_main)  # evaluates the flags
