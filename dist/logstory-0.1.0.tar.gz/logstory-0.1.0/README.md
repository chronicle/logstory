# logstory

Replay SecOps logs with updated timestamps.

## Installation

```bash
$ pip install logstory
```

## Configuration

It is easiest to configure your CLI flags in a flagfile like this one:

```
--customer_id=7e977ce4-f45d-43b2-aea0-52f8b66acd80
--credentials_path=/usr/local/google/home/dandye/.ssh/malachite-787fa7323a7d_bk_and_ing.json
--timestamp_delta=0d
```

## Usage

Assuming your flagfile is named config.cfg, you can invoke with:

```
logstory replay_usecase RULES_SEARCH_WORKSHOP --flagfile=config.cfg --timestamp_delta=1d --entities
logstory replay_usecase RULES_SEARCH_WORKSHOP --flagfile=config.cfg --timestamp_delta=0d
```

You can increase verbocity with by prepending the log level:
```
PYTHONLOGLEVEL=DEBUG logstory replay_usecase RULES_SEARCH_WORKSHOP --flagfile=config.cfg --timestamp_delta=0d
```

## Additional usecases

The usecases are stored in `<venv>/site-packages/logstory/usecases`

You can find the absolute path to that dir with:
```
 python -c 'import os; import logstory; print(os.path.split(logstory.__file__)[0])'
/usr/local/google/home/dandye/miniconda3/envs/pkg101_20241212_0453/lib/python3.13/site-packages/logstory
```

or:
```
ls -l $(python -c 'import os; import logstory; print(os.path.split(logstory.__file
__)[0])')
total 84
-rw-r----- 1 dandye primarygroup   110 Dec 12 16:02 __init__.py
-rw-r----- 1 dandye primarygroup 11967 Dec 12 16:02 logstory.py
-rw-r----- 1 dandye primarygroup  4707 Dec 12 16:02 logtypes_entities_timestamps.yaml
-rw-r----- 1 dandye primarygroup 30747 Dec 12 16:02 logtypes_events_timestamps.yaml
-rw-r----- 1 dandye primarygroup 16588 Dec 12 16:02 main.py
drwxr-x--- 2 dandye primarygroup  4096 Dec 12 16:02 __pycache__
drwxr-x--- 5 dandye primarygroup  4096 Dec 12 16:02 usecases
```

Download new usecases in that dir. For example:
```

```



## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`logstory` was created by Google Cloud Security. It is licensed under the terms of the Apache License 2.0 license.

## Credits

`logstory` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
